    # Backend - ConstruyeYa (Express + Supabase/Postgres)

## Configuración

Copia `.env.example` a `.env` y edítalo con tu conexión a Supabase (DATABASE_URL) y un `JWT_SECRET` seguro.

Para crear las tablas, puedes ejecutar `db_init.sql` en el SQL editor de Supabase o con psql.

## Rutas

- POST /api/auth/register { name, email, password }
- POST /api/auth/login { email, password } -> returns { token, user }
- GET /api/projects (protected)
- POST /api/projects (protected) { title, description }
- GET /api/projects/:id (protected)
- PUT /api/projects/:id (protected)
- DELETE /api/projects/:id (protected)

## Ejecutar

npm install
npm run dev
