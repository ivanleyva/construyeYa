import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import API from '../api/client'

export default function Login() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [status, setStatus] = useState('')
  const navigate = useNavigate()

  async function submit(e:any) {
    e.preventDefault()
    setStatus('Enviando...')
    try {
      const res = await API.post('/api/auth/login', { email, password })
      localStorage.setItem('token', res.data.token)
      localStorage.setItem('user', JSON.stringify(res.data.user))
      navigate('/dashboard')
    } catch (err:any) {
      setStatus(err?.response?.data?.message || 'Error')
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">
      <form onSubmit={submit} className="w-full max-w-md bg-white p-6 rounded shadow">
        <h2 className="text-xl font-semibold mb-4">Iniciar sesión</h2>
        <label className="block">Email<input className="w-full border p-2 mt-1" value={email} onChange={e=>setEmail(e.target.value)} required /></label>
        <label className="block mt-3">Contraseña<input type="password" className="w-full border p-2 mt-1" value={password} onChange={e=>setPassword(e.target.value)} required /></label>
        <button className="mt-4 px-4 py-2 bg-blue-600 text-white rounded">Entrar</button>
        {status && <p className="mt-3">{status}</p>}
      </form>
    </div>
  )
}
