import { Link } from 'react-router-dom'

export default function Dashboard() {
  const user = JSON.parse(localStorage.getItem('user') || '{}')
  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-3xl mx-auto bg-white p-6 rounded shadow">
        <h1 className="text-2xl font-bold">Bienvenido, {user.name || 'Usuario'}</h1>
        <p className="mt-3">Gestiona tus proyectos desde aquí.</p>
        <div className="mt-4">
          <Link to="/projects" className="px-4 py-2 bg-blue-600 text-white rounded">Ver Proyectos</Link>
        </div>
      </div>
    </div>
  )
}
