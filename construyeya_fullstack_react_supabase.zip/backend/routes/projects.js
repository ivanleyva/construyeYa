const express = require('express');
const router = express.Router();
const { pool } = require('../lib/db');
const jwt = require('jsonwebtoken');
const { body, validationResult } = require('express-validator');
const jwtSecret = process.env.JWT_SECRET || 'change_this_secret_for_prod';

// middleware auth
async function authMiddleware(req, res, next) {
  const auth = req.headers.authorization;
  if (!auth || !auth.startsWith('Bearer ')) return res.status(401).json({ message: 'No autorizado' });
  const token = auth.substring(7);
  try {
    const payload = jwt.verify(token, jwtSecret);
    req.user = { id: payload.userId, email: payload.email };
    next();
  } catch (err) {
    return res.status(401).json({ message: 'Token inválido' });
  }
}

// Create project
router.post('/', authMiddleware, [
  body('title').trim().isLength({ min: 3 }).withMessage('El título debe tener mínimo 3 caracteres'),
  body('description').optional().isString()
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

  const { title, description } = req.body;
  try {
    const result = await pool.query('INSERT INTO projects (owner_id, title, description) VALUES ($1,$2,$3) RETURNING id, title, description', [req.user.id, title, description || '']);
    res.json({ project: result.rows[0] });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Error del servidor' });
  }
});

// List projects for user
router.get('/', authMiddleware, async (req, res) => {
  try {
    const result = await pool.query('SELECT id, title, description FROM projects WHERE owner_id = $1 ORDER BY id DESC', [req.user.id]);
    res.json({ projects: result.rows });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Error del servidor' });
  }
});

// Get single
router.get('/:id', authMiddleware, async (req, res) => {
  const id = req.params.id;
  try {
    const result = await pool.query('SELECT id, title, description FROM projects WHERE id = $1 AND owner_id = $2', [id, req.user.id]);
    if (result.rowCount === 0) return res.status(404).json({ message: 'Proyecto no encontrado' });
    res.json({ project: result.rows[0] });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Error del servidor' });
  }
});

// Update
router.put('/:id', authMiddleware, [
  body('title').trim().isLength({ min: 3 }).withMessage('El título debe tener mínimo 3 caracteres'),
  body('description').optional().isString()
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });
  const id = req.params.id;
  const { title, description } = req.body;
  try {
    const result = await pool.query('UPDATE projects SET title=$1, description=$2 WHERE id=$3 AND owner_id=$4 RETURNING id, title, description', [title, description || '', id, req.user.id]);
    if (result.rowCount === 0) return res.status(404).json({ message: 'Proyecto no encontrado o no autorizado' });
    res.json({ project: result.rows[0] });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Error del servidor' });
  }
});

// Delete
router.delete('/:id', authMiddleware, async (req, res) => {
  const id = req.params.id;
  try {
    const result = await pool.query('DELETE FROM projects WHERE id=$1 AND owner_id=$2 RETURNING id', [id, req.user.id]);
    if (result.rowCount === 0) return res.status(404).json({ message: 'Proyecto no encontrado o no autorizado' });
    res.json({ message: 'Eliminado' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Error del servidor' });
  }
});

module.exports = router;
