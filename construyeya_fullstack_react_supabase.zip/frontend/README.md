    # Frontend - ConstruyeYa (React + React Router + Tailwind)

## Configurar

- Copia `.env.example` a `.env` y edita `VITE_API_URL` si tu backend corre en otro host.
- Instala dependencias: `npm install`
- Ejecuta en desarrollo: `npm run dev`

Rutas principales:
- /login
- /register
- /dashboard
- /projects
- /projects/:id
