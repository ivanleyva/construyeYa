import { useEffect, useState } from 'react'
import API from '../api/client'
import { Link, useNavigate } from 'react-router-dom'

export default function Projects() {
  const [projects, setProjects] = useState([])
  const [title, setTitle] = useState('')
  const [description, setDescription] = useState('')
  const [status, setStatus] = useState('')
  const navigate = useNavigate()

  async function load() {
    try {
      const res = await API.get('/api/projects')
      setProjects(res.data.projects)
    } catch (err:any) {
      navigate('/login')
    }
  }

  useEffect(()=>{ load() }, [])

  async function create(e:any) {
    e.preventDefault()
    try {
      const res = await API.post('/api/projects', { title, description })
      setProjects(prev=>[res.data.project, ...prev])
      setTitle(''); setDescription(''); setStatus('Creado ✅')
    } catch (err:any) {
      setStatus(err?.response?.data?.message || 'Error')
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-3xl mx-auto bg-white p-6 rounded shadow">
        <h1 className="text-2xl font-bold">Tus proyectos</h1>
        <form onSubmit={create} className="mt-4 space-y-2">
          <input value={title} onChange={e=>setTitle(e.target.value)} placeholder="Título" className="w-full border p-2" required />
          <textarea value={description} onChange={e=>setDescription(e.target.value)} placeholder="Descripción" className="w-full border p-2" />
          <button className="px-4 py-2 bg-green-600 text-white rounded">Crear proyecto</button>
        </form>
        {status && <p className="mt-2">{status}</p>}
        <ul className="mt-4 space-y-2">
          {projects.map((p:any)=>(
            <li key={p.id} className="border p-3 rounded">
              <Link to={`/projects/${p.id}`} className="text-lg font-semibold">{p.title}</Link>
              <p className="text-sm text-gray-600">{p.description}</p>
            </li>
          ))}
        </ul>
      </div>
    </div>
  )
}
