require('dotenv').config();
const express = require('express');
const cors = require('cors');
const app = express();
const authRouter = require('./routes/auth');
const projectsRouter = require('./routes/projects');

app.use(cors());
app.use(express.json());

app.use('/api/auth', authRouter);
app.use('/api/projects', projectsRouter);

const port = process.env.PORT || 8080;
app.listen(port, () => {
  console.log('Backend listening on', port);
});
