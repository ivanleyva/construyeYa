import { useEffect, useState } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import API from '../api/client'

export default function ProjectDetail() {
  const { id } = useParams()
  const [project, setProject] = useState<any>(null)
  const [status, setStatus] = useState('')
  const [title, setTitle] = useState('')
  const [description, setDescription] = useState('')
  const navigate = useNavigate()

  async function load() {
    try {
      const res = await API.get('/api/projects/' + id)
      setProject(res.data.project)
      setTitle(res.data.project.title)
      setDescription(res.data.project.description)
    } catch (err:any) {
      navigate('/projects')
    }
  }

  useEffect(()=>{ load() }, [id])

  async function save(e:any) {
    e.preventDefault()
    try {
      const res = await API.put('/api/projects/' + id, { title, description })
      setProject(res.data.project)
      setStatus('Guardado ✅')
    } catch (err:any) {
      setStatus(err?.response?.data?.message || 'Error')
    }
  }

  async function remove() {
    try {
      await API.delete('/api/projects/' + id)
      navigate('/projects')
    } catch (err:any) {
      setStatus('Error al eliminar')
    }
  }

  if (!project) return <p className="p-6">Cargando...</p>

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-3xl mx-auto bg-white p-6 rounded shadow">
        <h1 className="text-2xl font-bold">{project.title}</h1>
        <form onSubmit={save} className="mt-4 space-y-2">
          <input value={title} onChange={e=>setTitle(e.target.value)} className="w-full border p-2" required />
          <textarea value={description} onChange={e=>setDescription(e.target.value)} className="w-full border p-2" />
          <button className="px-4 py-2 bg-blue-600 text-white rounded">Guardar</button>
          <button type="button" onClick={remove} className="ml-2 px-4 py-2 bg-red-600 text-white rounded">Eliminar</button>
        </form>
        {status && <p className="mt-2">{status}</p>}
      </div>
    </div>
  )
}
